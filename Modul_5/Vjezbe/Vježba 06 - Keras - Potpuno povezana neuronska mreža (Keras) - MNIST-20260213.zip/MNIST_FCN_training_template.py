'''
Handwritten digits classification; MNIST dataset
Build, train and evaluate fully connected neural network in Keras

'''

from tensorflow import keras
from tensorflow.keras import layers
from matplotlib import pyplot as plt
import numpy as np
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report



# load the MNIST data
(x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data(path="mnist.npz")
print("Original x_train shape", x_train.shape)
print("Original y_train shape", y_train.shape)


# Scale input data (x_train and x_test) to [0,1]
x_train_s = x_train.astype("float32") / 255
x_test_s = x_test.astype("float32") / 255


# Reshape x_train and x_test for shape required by fully connected network
x_train_s = x_train_s.reshape(60000, 784)
x_test_s = x_test_s.reshape(10000, 784)


# appy one hot encoding to y_train and y_test
y_train_s = keras.utils.to_categorical(y_train, 10)
y_test_s = keras.utils.to_categorical(y_test, 10)


# TODO: show single train image and print its class in terminal



# TODO: build neural network; write down number of parameters for each layer



# TODO: check model structure and parameteres with .summary() method



# TODO: configure training with .compile() method



# TODO: train network using history = model.fit(....
# use 10% of the training data for validation



# TODO: show on same image train and val loss; show on same image train and val accuracy 



# TODO: evaluate built network on test data; print in terminal test loss and test accuracy



# TODO: use predict() to obtain predictions for test dataset
#       calculate metrics and confusion matrix on test dataset; use functions from scikit-learn



# TODO: save model to disk


